//
//  interface.hpp
//  Wav File Editor
//
//  Created by Johannes Koechling on 2020-11-22.
//

#ifndef interface_h
#define interface_h

#include <stdio.h>
#include <vector>
#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
//#include "interface.h"
using namespace std;

void Interface(string*);

#endif /* interface_hpp */
