//
//  correlation.hpp
//  correlation function
//
//  Created by Johannes Koechling on 2020-12-17.
//

#ifndef correlation_hpp
#define correlation_hpp

#include <stdio.h>
#include "report.hpp"

Report correlation(vector<int>*,vector<vector<int>>*,string);

#endif /* correlation_hpp */
